﻿// See https://aka.ms/new-console-template for more information
Console.Write("Ingrese su nombre: ");
string nombre = Console.ReadLine();

Console.WriteLine("Hola mundo");
Console.WriteLine("Soy " + nombre);

Console.Write("Hola mundo ");
Console.Write("soy " + nombre);
Console.ReadKey();
